import pagerank.PageRank;

/**
 * Main entry
 * 
 * @author Ke Wang
 *
 */
public class Main {

	public static void main(String[] args) {
		new PageRank().start();
	}

}